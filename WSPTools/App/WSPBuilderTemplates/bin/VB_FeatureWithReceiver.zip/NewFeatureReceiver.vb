Imports System
Imports System.Collections.Generic
Imports System.Text
Imports Microsoft.SharePoint

Namespace $DefaultNamespace$
    Class $rootname$
        Inherits SPFeatureReceiver
        Public Overloads Overrides Sub FeatureActivated(ByVal properties As SPFeatureReceiverProperties)
            Throw New Exception("The method or operation is not implemented.")
        End Sub

        Public Overloads Overrides Sub FeatureDeactivating(ByVal properties As SPFeatureReceiverProperties)
            Throw New Exception("The method or operation is not implemented.")
        End Sub

        Public Overloads Overrides Sub FeatureInstalled(ByVal properties As SPFeatureReceiverProperties)
            Throw New Exception("The method or operation is not implemented.")
        End Sub

        Public Overloads Overrides Sub FeatureUninstalling(ByVal properties As SPFeatureReceiverProperties)
            Throw New Exception("The method or operation is not implemented.")
        End Sub
    End Class
End Namespace

