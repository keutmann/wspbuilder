﻿namespace $RootNamespace$.UI
{
    public partial class $rootname$UserControl
    {
    }
}
